<?php
// someday if you want do init action before testing
class TestCase extends \PHPUnit_Framework_TestCase{
}

