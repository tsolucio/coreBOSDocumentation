<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author alhajr <alhajr300@gmail.com>
 */
$lang['menu']                  = 'تحقق من تكوين سويفتميل';
$lang['nofrom']                = 'أنت لم تكوين الخيار \'mailfrom\'. إرسال الرسائل ستفشل على الأرجح.';
