<?php

$lang['menu'] = '检查 SMTP 配置';
$lang['nofrom'] = '您没有配置“mailfrom”选项。邮件发送可能会失败。';
