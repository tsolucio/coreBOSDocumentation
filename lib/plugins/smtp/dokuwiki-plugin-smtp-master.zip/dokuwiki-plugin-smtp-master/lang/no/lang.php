<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Daniel Raknes <rada@jbv.no>
 * @author Arne Hanssen <arne.hanssen@getmail.no>
 */
$lang['menu']                  = 'Sjekk SMTP-konfigurasjonen';
$lang['nofrom']                = 'Du har ikke konfigurerte «Avsenderadresse for automatiske e-poster». Sending av e-post vil sannsynligvis ikke virke.';
