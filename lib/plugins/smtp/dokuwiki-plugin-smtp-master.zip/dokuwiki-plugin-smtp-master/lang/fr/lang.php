<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Schplurtz le Dévoulonné <Schplurtz@laposte.net>
 * @author Schplurtz le Déboulonné <Schplurtz@laposte.net>
 */
$lang['menu']                  = 'Vérifier la configuration de SMTP';
$lang['nofrom']                = 'Vous n\'avez pas configuré l\'option \'De\'. L\'envoi de courriel va probablement échouer.';
