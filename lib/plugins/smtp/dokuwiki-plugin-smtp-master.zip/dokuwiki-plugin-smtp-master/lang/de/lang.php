<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Dominik Eckelmann <deckelmann@gmail.com>
 */
$lang['menu']                  = 'Überprüfe SMTP Konfiguration';
$lang['nofrom']                = 'Sie haben die "mailfrom" Option nicht gesetzt. Der E-Mail Versand wird deshalb vermutlich fehlschlagen.';
