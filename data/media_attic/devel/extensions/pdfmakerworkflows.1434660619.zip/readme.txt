################################################# EXPRESS INSTALLATION #################################################
* Copy files and rewrite if necessary.
************************************************************************************************************************************


################################################# CUSTOM INSTALLATION #################################################
* FILE modules/com_vtiger_workflow/language/en_us.lang.php
* AROUND LINE 87 AFTER
 
'LBL_NO_ENTITIES_FOUND' => 'No Entities Found to Create',

* ADD FOLLOWING:

// ITS4YOU-CR PDF Maker
'VTPDFMakerTask'=>'Save document from PDFMaker',
'VTPDFMakerMailTask'=>'Send Email with PDFMaker attachment',
// ITS4YOU-END
************************************************************************************************************************************
* FILE modules/com_vtiger_workflow/tasks/VTPDFMakerTask.inc
* THIS IS NEW FILE JUST COPY IT  
************************************************************************************************************************************
* FILE modules/com_vtiger_workflow/tasks/VTPDFMakerMailTask.inc
* THIS IS NEW FILE JUST COPY IT
************************************************************************************************************************************
* FILE modules/com_vtiger_workflow/VTTaskManager.inc
* AROUND LINE 123 AFTER

if(getTabid('SMSNotifier') && vtlib_isModuleActive('SMSNotifier')) {
	$taskTypes [] = 'VTSMSTask'; 	
}

* ADD FOLLOWING:

// ITS4YOU-CR PDF Maker
if(getTabid('PDFMaker') && vtlib_isModuleActive('PDFMaker')) {
	$taskTypes [] = 'VTPDFMakerTask';
    $taskTypes [] = 'VTPDFMakerMailTask';
}
// ITS4YOU-END
************************************************************************************************************************************
* FILE Smarty/templates/com_vtiger_workflow/taskforms/VTPDFMakerTask.tpl
* THIS IS NEW FILE JUST COPY IT
************************************************************************************************************************************
************************************************************************************************************************************
* FILE Smarty/templates/com_vtiger_workflow/taskforms/VTPDFMakerMailTask.tpl
* THIS IS NEW FILE JUST COPY IT
************************************************************************************************************************************
*
*
####################################################################################################################################
######################################## UPGRADE FROM PREVIOUS VERSION OF PDFMAKER WORKFLOW ########################################
####################################################################################################################################

Follow these steps only in case you've had previous version of PDFMaker workflow installed
* FILE modules/com_vtiger_workflow/resources/emailtaskscript.js
* AROUND LINE 206 REMOVE FOLLOWING:

// ITS4YOU-CR PDF Maker
function fillTemplatesBox(id)
{
	workflowid = document.getElementById('save_workflow_id').value;
  select_template =  document.getElementById('task-templatevalue').value;

  new Ajax.Request(
              'index.php',
              {queue: {position: 'end', scope: 'command'},
                      method: 'post',
                      postBody: "module=PDFMaker"+"&action=PDFMakerAjax&file=GetPDFTemplates&src_module=PDFMaker&none=yes&workflowid="+workflowid,
                      onComplete: function(response) {
        								var folders = response.responseText.split("###");

                        if (response.responseText == "EMPTY")
                        {
                            document.getElementById('task-template-busyicon').innerHTML = "<font color='red'>no templates</font>";
                        }
                        else
                        {
                            $('#task-template-busyicon').hide();
                            $('#task-template').show();
            								var select = $('#task-template');
            								var optionClass = 'task-template-option';
            								$.each(folders, function(k, v){
            									val = v.split("@");

                              if (select_template == val[0]) sel = "selected"; else  sel = "";

                              select.append('<option class="'+optionClass+'" '+ 'value="'+val[0]+'" '+sel+'>' + val[1] + '</option>');
            								});
        								}
        							}
              }
      );
}
// ITS4YOU-END

************************************************************************************************************************************
* FILE modules/com_vtiger_workflow/resources/emailtaskscript.js
* AROUND LINE 310 REMOVE FOLLOWING:

// ITS4YOU-CR PDF Maker
fillTemplatesBox('task-template');
$('#task-template').change(function(){
	var input = $($('#task-template').get());
	var value = $("#task-template option[value='"+$(this).val()+"']").text();
	input.attr("value", value);
});
// ITS4YOU-END

************************************************************************************************************************************
* FILE modules/com_vtiger_workflow/tasks/VTEmailTask.inc
* AROUND LINE 19 REPLACE

return array("subject", "content", "recepient", 'emailcc', 'emailbcc', 'template'); // ITS4YOU-CR PDF Maker

* WITH FOLLOWING:

return array("subject", "content", "recepient", 'emailcc', 'emailbcc');

************************************************************************************************************************************
* FILE modules/com_vtiger_workflow/tasks/VTEmailTask.inc
* AROUND LINE 50 REPLACE

// ITS4YOU-CR PDF Maker
$templateid = $this->template;
if ($templateid != "0" && $templateid != "")
{
    require_once('modules/PDFMaker/PDFMaker.php');
    require_once("modules/PDFMaker/mpdf/mpdf.php");
    require_once("modules/PDFMaker/InventoryPDF.php");

    list($id3, $id) = explode("x",$entity->getId());

    $modFocus = CRMEntity::getInstance($module);

    $modFocus->retrieve_entity_info($id,$module);
    $modFocus->id = $id;

    $result=$adb->query("SELECT fieldname FROM vtiger_field WHERE uitype=4 AND tabid=".getTabId($module));
    $fieldname=$adb->query_result($result,0,"fieldname");
    if(isset($modFocus->column_fields[$fieldname]) && $modFocus->column_fields[$fieldname]!="")
    {
        $file_name = generate_cool_uri($modFocus->column_fields[$fieldname]).".pdf";
    }
    else
    {
        $file_name = $templateid.$focus->parentid.date("ymdHi").".pdf";
    }

    require_once('modules/Emails/Emails.php');
    require_once('include/logging.php');
    require_once('include/database/PearDatabase.php');


    $focus = new Emails();
    //assign the focus values
    $focus->filename = $file_name;
    $focus->column_fields["assigned_user_id"]=$current_user->id;
    $focus->column_fields["activitytype"]="Emails";
    $focus->column_fields["subject"]=$subject;
    $focus->column_fields["description"]=$content;
    $focus->column_fields["date_start"]= date(getNewDisplayDate());

    $focus->save("Emails");

		$adb->pquery('insert into vtiger_seactivityrel values(?,?)', array($id, $focus->id));

    $to_email_up = '["'.str_replace(',','","',trim($to_email,",")).'"]';
    $adb->query("UPDATE vtiger_emaildetails SET to_email = '".$to_email_up."' WHERE emailid = '".$focus->id."'");

    $language = $_SESSION['authenticated_user_language'];
    createPDFAndSaveFile($templateid,$focus,$modFocus,$file_name,$module,$language);

    send_mail($module,$to_email,$from_name,$from_email,$subject,$content,$cc,$bcc,'all',$focus->id);
}
else
{
    send_mail($module,$to_email,$from_name,$from_email,$subject,$content,$cc,$bcc);
}

* WITH FOLLOWING:

send_mail($module,$to_email,$from_name,$from_email,$subject,$content, $cc, $bcc);

// ITS4YOU-END

************************************************************************************************************************************
* FILE Smarty/templates/com_vtiger_workflow/taskforms/VTEmailTask.tpl
* AROUND LINE 30 REMOVE FOLLOWING:

{* ITS4YOU-CR PDF Maker *}
<tr valign="top">
	<td class='dvtCellLabel' align="right" width=15% nowrap="nowrap"><b>PDF Template</b></td>
	<td class='dvtCellInfo'>
		<span id="task-template-busyicon"><b>{$MOD.LBL_LOADING}</b><img src="{'vtbusy.gif'|@vtiger_imageurl:$THEME}" border="0"></span>
		<select id="task-template" name="template" class="small" style="display: none;"></select>
		<input type="hidden" id="task-templatevalue" value="{$task->template}">
	</td>
</tr>
{* ITS4YOU-END *}
************************************************************************************************************************************