function askToProceed(edit_type, formName, action, callback, message) {
	var goahead = confirm(message);
	VtigerJS_DialogBox.unblock();
	if (goahead) {
		return true;
	} else {
		return false;
	}
}