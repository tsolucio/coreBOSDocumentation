function askToProceed(edit_type, formName, action, callback, message) {
	var goahead = confirm(message);
	if (goahead) {
		if (typeof callback == 'function') {
			callback('submit');
		} else {
			submitFormForAction(formName, action);
		}
	}
	VtigerJS_DialogBox.unblock();
}