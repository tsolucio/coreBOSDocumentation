<?php
/*************************************************************************************************
** PUT YOUR LICENSE HERE **
 *************************************************************************************************/

// PRESAVE ACTION: block://askQuestionOnSave:modules/Utilities/askQuestionOnSave.php:recordid=$RECORD$
// javascript action: modules/Assets/askToProceed.js

require_once 'modules/Vtiger/DeveloperWidget.php';
global $currentModule;

class askQuestionOnSave {
	// Get class name of the object that will implement the widget functionality
	public static function getWidget($name) {
		return (new askQuestionOnSave_DetailViewBlock());
	}
}

class askQuestionOnSave_DetailViewBlock extends DeveloperBlock {
	// Implement widget functionality
	private $widgetName = 'askQuestionOnSave';

	// This one is called to get the contents to show on screen
	public function process($context = false) {
		global $adb;
		$this->context = $context;
		$smarty = $this->getViewer();
		return '%%%FUNCTION%%%askToProceed%%%PARAMS%%%Should we proceed?';
	}
}
