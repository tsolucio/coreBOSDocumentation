<?php
/*************************************************************************************************
 * Copyright 2012 JPL TSolucio, S.L.  --  This file is a part of vtyiiCPNG.
 * You can copy, adapt and distribute the work under the "Attribution-NonCommercial-ShareAlike"
 * Vizsage Public License (the "License"). You may not use this file except in compliance with the
 * License. Roughly speaking, non-commercial users may share and modify this code, but must give credit
 * and share improvements. However, for proper details please read the full License, available at
 * http://vizsage.com/license/Vizsage-License-BY-NC-SA.html and the handy reference for understanding
 * the full license at http://vizsage.com/license/Vizsage-Deed-BY-NC-SA.html. Unless required by
 * applicable law or agreed to in writing, any software distributed under the License is distributed
 * on an  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and limitations under the
 * License terms of Creative Commons Attribution-NonCommercial-ShareAlike 3.0 (the License).
*************************************************************************************************
*  Author       : JPL TSolucio, S. L.
*************************************************************************************************/

// Functions used to manage Portal Users

function vtws_findByPortalUserName($username) {
	global $adb,$log;
	$log->debug("Entering function vtws_findByPortalUserName");
	$nra=$adb->getone("select count(*) from vtiger_portalinfo where isactive=1 and user_name='".$username."'");
	if (empty($nra))
		$output=false;
	else	
		$output=true;
	$log->debug("Exiting function vtws_findByPortalUserName");
	return $output;
}

function vtws_sendRecoverPassword($username) {
	global $adb,$log,$current_user, $PORTAL_URL, $url_code;;
	$log->debug("Entering function vtws_sendRecoverPassword");

	require_once("modules/Emails/mail.php");
	require_once("include/utils/CommonUtils.php");
	$ctors=$adb->query("select firstname,lastname,email,user_password
			 from vtiger_contactdetails
			 inner join vtiger_portalinfo on id=contactid
			 where isactive=1 and user_name='$username'");
	$cto=$adb->fetch_array($ctors);
	$data_array = Array();
	$data_array['first_name'] = $cto['firstname'];
	$data_array['last_name'] = $cto['lastname'];
	$data_array['email'] = $cto['email'];
	$data_array['username'] = $username;
	$password = $cto['user_password'];
	$data_array['portal_url'] = '<a href="'.$PORTAL_URL.'" style="font-family:Arial, Helvetica, sans-serif;font-size:12px; font-weight:bolder;text-decoration:none;color: #4242FD;">'.getTranslatedString('Please Login Here','Contacts').'</a>';
	$contents= getmail_contents_portalUser($data_array,$password);
	$subject = getTranslatedString('Customer Portal Login Details','Contacts');
	$mail_status = send_mail('Contacts',$cto['email'],$current_user->user_name,"",$subject,$contents);
	
	$log->debug("Exiting function vtws_sendRecoverPassword");
	return $mail_status;
}

?>