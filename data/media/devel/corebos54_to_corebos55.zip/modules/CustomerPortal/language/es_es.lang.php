<?php
/* Spanish Translation File
** Author: JPL TSolucio, S.L. Joe Bordes
** Distributed under MPL 1.1
*/
$mod_strings = Array (
'CustomerPortal' => 'Portal Cliente',
'LBL_BASIC_SETTINGS'=>'Configuración Básica',
'LBL_CUSTOMERPORTAL_SETTINGS'=>'Configuración Portal',
'LBL_ADVANCED_SETTINGS'=>'Configuración Avanzada',
'LBL_MODULE'=>'Módulo',
'LBL_VIEW_ALL_RECORD'=>'¿Mostrar todos los registros relacionados?',
'LBL_MODULE_INFORMATION'=>'Información Módulo',
'LBL_USER_INFORMATION'=>'Información Usuario',
'LBL_YES'=>'Sí',
'LBL_NO'=>'No',
'LBL_USER_DESCRIPTION'=>'NOTA : El perfil del usuario seleccionado arriba controlará qué campos aparecen en el Portal de Cliente.',
'LBL_GROUP_DESCRIPTION'=>'NOTA : Las incidencias se asignarán al usuario/grupo por defecto seleccionado.',
'LBL_SELECT_USERS'=>'Perfil Usuarios',
'LBL_DEFAULT_USERS'=>'Asignado por defecto',
'LBL_DISABLE'=>'Deshabilitar',
'LBL_ENABLE' =>'Habilitar',
'LBL_MODULE' => 'Módulo',
'LBL_SEQUENCE' =>'Secuencia',
'LBL_VISIBLE'=>'Visible'
);

?>
