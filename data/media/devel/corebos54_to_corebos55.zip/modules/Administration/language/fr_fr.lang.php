<?php
/***********************************************************
*  Module       : Administration
*  Language     : French
*  Version      : 5.4.0 
*  License      : GPL
*  Author       : ABOnline solutions http://www.vtiger-crm.fr
***********************************************************/

$mod_strings = array (
	'LBL_MODULE_NAME' => 'Administration',
	'LBL_MODULE_TITLE' => 'Administration : ',
	'LBL_NEW_FORM_TITLE' => 'Nouveau compte',
	'ERR_DELETE_RECORD' => 'Un numéro d\'enregistrement doit être renseigné pour supprimer le compte.',
);
$mod_list_strings = array (
);
?>