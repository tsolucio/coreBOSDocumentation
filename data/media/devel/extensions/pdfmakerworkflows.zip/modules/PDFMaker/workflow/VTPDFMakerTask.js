/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************/
function PDFMakerTask($) {
    var map = fn.map;
    var dict = fn.dict;
    var filter = fn.filter;
    var reduceR = fn.reduceR;
    var parallelExecuter = fn.parallelExecuter;
    var contains = fn.contains;
    var concat = fn.concat;
    var vtinst = new VtigerWebservices("webservice.php");

    function handleError(fn) {
        return function(status, result) {
            if (status) {
                fn(result);
            } else {
                errorDialog('Failure:' + result);
            }
        };
    }

    //Convert user type into reference for consistency in describe objects
    //This is done inplace
    function referencify(desc) {
        var fields = desc['fields'];
        for (var i = 0; i < fields.length; i++) {
            var field = fields[i];
            var type = field['type'];
            if (type['name'] == 'owner') {
                type['name'] = 'reference';
                type['refersTo'] = ['Users'];
            }
        }
        return desc;
    }

    function diff(reflist, list) {
        var out = [];
        $.each(list, function(i, v) {
            if (contains(reflist, v)) {
                out.push(v);
            }
        });
        return out;
    }

    //Insert text at the cursor
    function insertAtCursor(element, value) {
        //http://alexking.org/blog/2003/06/02/inserting-at-the-cursor-using-javascript
        if (document.selection) {
            element.focus();
            var sel = document.selection.createRange();
            sel.text = value;
            element.focus();
        } else if (element.selectionStart || element.selectionStart == '0') {
            var startPos = element.selectionStart;
            var endPos = element.selectionEnd;
            var scrollTop = element.scrollTop;
            element.value = element.value.substring(0, startPos)
                    + value
                    + element.value.substring(endPos,
                    element.value.length);
            element.focus();
            element.selectionStart = startPos + value.length;
            element.selectionEnd = startPos + value.length;
            element.scrollTop = scrollTop;
        } else {
            element.value += value;
            element.focus();
        }
    }

    function fillFolderBox(id)
    {
        select_folder = document.getElementById('task_folder_value').value;

        $.ajax({
                    url: "index.php?module=PDFMaker" + "&action=PDFMakerAjax&file=GetDocFolders&src_module=PDFMaker",
                    success: function(response) {
                        var folders = response.split("###");
                        //alert(response.responseText);
                        $('#task_folder_busyicon').hide();
                        $('#task_folder').show();
                        var select = $('#' + id);
                        var optionClass = id + '_option';
                        $.each(folders, function(k, v) {
                            val = v.split("@");

                            if (select_folder == val[0])
                                sel = "selected";
                            else
                                sel = "";

                            select.append('<option class="' + optionClass + '" ' + 'value="' + val[0] + '" ' + sel + '>' + val[1] + '</option>');
                        });

                        //$('#task_folder').val($("#task_folder option[value='0']").text());
                    }
        });
    }

    function fillTemplatesBox(id)
    {
        workflowid = document.getElementById('save_workflow_id').value;
        select_template = document.getElementById('task_template_value').value;

        $.ajax({
                    url: "index.php?module=PDFMaker" + "&action=PDFMakerAjax&file=GetPDFTemplates&src_module=PDFMaker&workflowid=" + workflowid,
                    success: function(response) {
						var tpllang = response.split("%%%");
						// templates
						var folders = tpllang[0].split("###");
                        $('#task_template_busyicon').hide();
                        $('#task_template').show();

                        var select = $('#task_template');
                        var optionClass = 'task_template_option';
                        $.each(folders, function(k, v) {
                            val = v.split("@");

                            if (select_template == val[0])
                                sel = "selected";
                            else
                                sel = "";

                            select.append('<option class="' + optionClass + '" ' + 'value="' + val[0] + '" ' + sel + '>' + val[1] + '</option>');
                        });
						//append the selectbox for PDF language
						var langselect = '&nbsp;&nbsp;<select name="template_language" class="small">';
						var langs = tpllang[1].split('###');
						var select_language = $('#template_language_value').val();
						$.each(langs, function(k, v) {
                            val = v.split("@");
                            if (select_language == val[0])
                                sel = "selected";
                            else
                                sel = "";
							langselect += '<option class="' + optionClass + '" ' + 'value="' + val[0] + '" ' + sel + '>' + val[1] + '</option>';
                        });
						langselect += '</select>';
						select.parent().append(langselect);

                        //$('#task_template').val($("#task_template option[value='0']").text());
                    }
        });
    }

    function fillSelectBox(id, modules, parentModule, filterPred) {
        if (filterPred == null) {
            filterPred = function() {
                return true;
            };
        }
        var parent = modules[parentModule];
        var fields = parent['fields'];
        function filteredFields(fields) {
            return filter(
                    function(e) {
                        var fieldCheck = !contains(['autogenerated', 'reference', 'owner', 'multipicklist', 'password'], e.type.name);
                        var predCheck = filterPred(e);
                        return fieldCheck && predCheck;
                    },
                    fields
                    );
        }
        var parentFields = map(function(e) {
            return[e['name'], e['label']];
        }, filteredFields(parent['fields']));

        var referenceFieldTypes = filter(function(e) {
            return (e['type']['name'] == 'reference');
        }, parent['fields']
                );

        var moduleFieldTypes = {};
        $.each(modules, function(k, v) {
            moduleFieldTypes[k] = dict(map(function(e) {
                return [e['name'], e['type']];
            }, filteredFields(v['fields'])));
        }
        );

        function getFieldType(fullFieldName) {
            var group = fullFieldName.match(/(\w+) : \((\w+)\) (\w+)/);
            if (group == null) {
                var fieldModule = moduleName;
                var fieldName = fullFieldName;
            } else {
                var fieldModule = group[2];
                var fieldName = group[3];
            }
            return moduleFieldTypes[fieldModule][fieldName];
        }

        function fieldReferenceNames(referenceField) {
            var name = referenceField['name'];
            var label = referenceField['label'];
            function forModule(moduleName) {
                // If module is not accessible return no field information
                if (!contains(accessibleModulesInfo, moduleName))
                    return [];

                return map(function(field) {
                    return ['(' + name + ' : ' + '(' + moduleName + ') ' + field['name'] + ')', label + ' : ' + '(' + moduleName + ') ' + field['label']];
                },
                        filteredFields(modules[moduleName]['fields']));
            }
            return reduceR(concat, map(forModule, referenceField['type']['refersTo']), []);
        }

        var referenceFields = reduceR(concat, map(fieldReferenceNames, referenceFieldTypes), []);
        var fieldLabels = dict(parentFields.concat(referenceFields));
        var select = $('#' + id);
        var optionClass = id + '_option';
        $.each(fieldLabels, function(k, v) {
            select.append('<option class="' + optionClass + '" ' + 'value="' + k + '">' + v + '</option>');
        });

    }

    //Get an array containing the the description of a module and all modules
    //refered to by it. This is passed to callback.
    function getDescribeObjects(accessibleModules, moduleName, callback) {
        vtinst.describeObject(moduleName, handleError(function(result) {
            var parent = referencify(result);
            var fields = parent['fields'];
            var referenceFields = filter(function(e) {
                return e['type']['name'] == 'reference';
            },
                    fields);
            var referenceFieldModules =
                    map(
                    function(e) {
                        return e['type']['refersTo'];
                    },
                    referenceFields
                    );
            function union(a, b) {
                var newfields = filter(function(e) {
                    return !contains(a, e);
                }, b);
                return a.concat(newfields);
            }
            var relatedModules = reduceR(union, referenceFieldModules, [parent['name']]);

            // Remove modules that is no longer accessible
            relatedModules = diff(accessibleModules, relatedModules);

            function executer(parameters) {
                var failures = filter(function(e) {
                    return e[0] == false;
                }, parameters);
                if (failures.length != 0) {
                    var firstFailure = failures[0];
                    callback(false, firstFailure[1]);
                } else {
                    var moduleDescriptions = map(function(e) {
                        return referencify(e[1]);
                    },
                            parameters);
                    var modules = dict(map(function(e) {
                        return [e['name'], e];
                    },
                            moduleDescriptions));
                    callback(true, modules);
                }
            }
            var p = parallelExecuter(executer, relatedModules.length);
            $.each(relatedModules, function(i, v) {
                p(function(callback) {
                    vtinst.describeObject(v, callback);
                });
            });
        }));
    }


    $(document).ready(function() {
        vtinst.extendSession(handleError(function(result) {
            vtinst.listTypes(handleError(function(accessibleModules) {
                accessibleModulesInfo = accessibleModules;

                getDescribeObjects(accessibleModules, moduleName, handleError(function(modules) {

                    document.getElementById("check_select_date").disabled = true;

                    fillFolderBox('task_folder');
// 					$('#task_folder').change(function(){
// 						var input = $($('#task_folder').get());
// 						var value = $("#task_folder option[value='"+$(this).val()+"']").text();
// 						input.val(value);
// 					});

                    fillTemplatesBox('task_template');
// 					$('#task_template').change(function(){
// 						var input = $($('#task_template').get());
// 						var value = $("#task_template option[value='"+$(this).val()+"']").text();
// 						input.val(value);
// 					});

                }));

            }));
        }));
        validator.mandatoryFields.push('title');
    });
}

PDFMakerTask(jQuery);
