################################################# EXPRESS INSTALLATION #################################################
* Unzip file from the root of your coreBOS install (the directory the config.inc.php file is)
* Add the two translation strings below to your language files and translate
* Go to coreBOS Updater; load and apply PDFMaker changeset
************************************************************************************************************************

* FILE modules/com_vtiger_workflow/language/en_us.lang.php, ADD FOLLOWING:

// ITS4YOU-CR PDF Maker
'VTPDFMakerTask'=>'Save document from PDFMaker',
'VTPDFMakerMailTask'=>'Send Email with PDFMaker attachment',
// ITS4YOU-END
