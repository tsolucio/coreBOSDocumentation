<?php
global $adb;
require_once('Smarty_setup.php');

class ContactPOInfoWidget {
	// Get class name of the object that will implement the widget functionality
	static function getWidget($name) {
		return (new ContactPOInfoWidget_DetailViewBlock());
	}
}

class ContactPOInfoWidget_DetailViewBlock {
	// Implement widget functionality
	private $_name = 'ContactPOInfoWidget';
	protected $context = false;
	
	function title() {
		return getTranslatedString('Purchase Order Statistics', 'Contacts');
	}
	
	function name() {
		return $this->_name;
	}
	
	function uikey() {
		return "ContactPOInfoWidget_DetailViewBlock";
	}
	
	// Helper method to setup Smarty
	function getViewer() {
		global $theme, $app_strings, $current_language;
	
		$smarty = new vtigerCRM_Smarty();
		$smarty->assign('APP', $app_strings);
		$smarty->assign('MOD', return_module_language($current_language,'Contacts'));
		$smarty->assign('THEME', $theme);
		$smarty->assign('IMAGE_PATH', "themes/$theme/images/");
	
		$smarty->assign('UIKEY', $this->uikey());
		$smarty->assign('WIDGET_TITLE', $this->title());
		$smarty->assign('WIDGET_NAME', $this->name());
	
		return $smarty;
	}
	
	// This one is called to get the contents to show on screen
	function process($context = false) {
		global $adb;
		$smarty = $this->getViewer();
		$this->context = $context;
		$sourceRecordId =  $this->getFromContext('ID', true);
		
		// Special purchase order count and sum information
		// We get the info from database and send it to smarty
		$pors = $adb->pquery('select count(*), sum(total) from vtiger_purchaseorder where contactid=?',array($sourceRecordId));
		if ($pors) {
			$smarty->assign('CONTACTPOCOUNT',$adb->query_result($pors,0,0));
			$smarty->assign('CONTACTPOSUM',$adb->query_result($pors,0,1));
		}
		
		return $smarty->fetch("modules/ContactPOInfoWidget.tpl");
	}
	
	// Helper method
	function getFromContext($key, $purify=false) {
		if ($this->context) {
			$value = $this->context[$key];
			if ($purify && !empty($value)) {
				$value = vtlib_purify($value);
			}
			return $value;
		}
		return false;
	}

}
